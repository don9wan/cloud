-- AlterTable
ALTER TABLE "experience" ADD COLUMN     "index" INTEGER NOT NULL DEFAULT 0;
